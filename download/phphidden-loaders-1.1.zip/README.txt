PHPHIDDEN 1.0 LOADER PACKAGE
====================================================================
You can find Linux loaders in `linux` folder and Windows loaders in
`win` folder.

Thread Safe loaders are in `-zts` folders and Non Thread Safe 
loaders are in `-no-zts` folders.

System requirements:
====================================================================
- Linux or Windows 64bit server
- At least 2 GB free RAM

- Tested on:
     Debian 12, Debian 11, Ubuntu 18.04, Ubuntu 20.04, Ubuntu 22.04
     with Apache 2 and Nginx web servers
     
     Windows 7 64bit, Windows 10
     with Apache 2 web server

Installation
====================================================================
To install correct version on your server you can use assistant.php
Just upload it on your server and open it in your browser.

If you want to install extension on your cli too, use this command:

php -f /path_to_loaders/assistant.php

Manual installation
====================================================================
Copy correct dll/so file to your php extension folder and add
following lines at the ***BEGINNING*** of your php.ini:

[phphidden]
extension=phphidden

for older php version:
[phphidden]
extension=phphidden.so for Linux or phphidden.dll for Windows


For more info visit:
https://www.phphidden.com/


