<?php

$cli = (php_sapi_name() == 'cli'?true:false);
$br = ($cli?"\n\r":'<br>');
$win = (strtoupper(substr(PHP_OS, 0, 3)) == 'WIN'?true:false);
$phpver=PHP_MAJOR_VERSION .'.'.PHP_MINOR_VERSION;
$extpath = ini_get("extension_dir");
$zts=(ZEND_THREAD_SAFE);
$code=($cli?'':'<code>');
$code_e=($cli?'':'</code>');

echo $br."phphidden status: ";
if(extension_loaded("phphidden")) {
	if($cli)
		echo "Installed";
	else
		echo "<span style='color:darkgreen'>Installed</span>";	
echo $br.$br;
} else {
	if($cli)
		echo "Not Installed";
	else
		echo "<span style='color:red'>Not Installed</span>";	

echo $br.$br;

echo "To install phphidden extension on your server;".$br.$br;
echo " 1. Copy file `phphidden.".($win?'dll':'so')."` for PHP version ".$phpver.($win?($zts?'  (thread safe)':' (non thread safe)'):'').$br.
         "     from folder `loaders/".($win?"win/php":"linux/php").$phpver.($win?($zts?'-zts':'-no-zts'):'')."` to ".$br.
         "     folder `".$extpath."`".$br.$br.
$code.($win?
		 "     copy .\\loaders\\win\\php".$phpver.($zts?'-zts':'-no-zts')."\\phphidden.".($win?'dll':'so')." ".$extpath."\\"
:		 "     sudo cp ./loaders/linux/php".$phpver."/phphidden.".($win?'dll':'so')." ".$extpath."/").$code_e
.$br.$br;
echo " 2. Add the following two lines at the BEGINNING of".$br.
		 "     the file `".php_ini_loaded_file()."`:".$br.$br;
echo $code."[phphidden]".$br."extension=phphidden";

if(PHP_VERSION_ID >= 70200) {
	echo "";
} else {
	if(win)
		echo ".dll";
	else
		echo ".so";
}

echo $code_e;

if(!$cli)
	echo $br.$br." 3. Restart your web service (apache2, nginx,...) and fpm service (if used).".$br.$br;

echo $br.$br."Then ".($cli?"re-run this script.":"refresh this page.").$br.$br;
}
