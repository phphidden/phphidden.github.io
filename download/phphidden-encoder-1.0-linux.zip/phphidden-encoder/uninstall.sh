#!/bin/sh


rm ~/.local/share/applications/phpHidden.desktop

