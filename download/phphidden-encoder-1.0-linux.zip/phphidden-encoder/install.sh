#!/bin/sh


BASE_DIR=$(dirname "$(readlink -f "$0")")

echo "[Desktop Entry]
Type=Application
Terminal=false
Exec=$BASE_DIR/phpHidden.sh
Name=phpHidden
Icon=$BASE_DIR/appicon.png
Categories=Development;Utility" > "$BASE_DIR/phpHidden.desktop"

chmod +x "$BASE_DIR/phpHidden.desktop"

echo "$BASE_DIR/phpHidden.desktop created!"

cp "$BASE_DIR/phpHidden.desktop" ~/.local/share/applications/

echo "~/.local/share/applications/phpHidden.desktop created!"
